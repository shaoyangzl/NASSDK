#import <Flutter/Flutter.h>

@interface PdfRenderPlugin : NSObject<FlutterPlugin>
@end
