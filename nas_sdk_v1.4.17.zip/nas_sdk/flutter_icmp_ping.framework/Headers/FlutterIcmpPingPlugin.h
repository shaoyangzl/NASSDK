#import <Flutter/Flutter.h>
#import "GBPing.h"

@interface FlutterIcmpPingPlugin : NSObject<FlutterPlugin>
@end
