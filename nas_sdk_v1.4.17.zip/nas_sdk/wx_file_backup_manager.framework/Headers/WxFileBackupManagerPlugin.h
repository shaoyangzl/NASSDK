#import <Flutter/Flutter.h>

@interface WxFileBackupManagerPlugin : NSObject<FlutterPlugin>
@end
