#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "WxFileBackupManagerPlugin.h"

FOUNDATION_EXPORT double wx_file_backup_managerVersionNumber;
FOUNDATION_EXPORT const unsigned char wx_file_backup_managerVersionString[];

