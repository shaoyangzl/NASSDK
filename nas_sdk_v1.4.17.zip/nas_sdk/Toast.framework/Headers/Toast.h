//
//  Toast.h
//  Toast
//
//  Created by Charles Scalesse on 11/3/16.
//
//

#import <UIKit/UIKit.h>

//! Project version number for Toast.
FOUNDATION_EXPORT double ToastVersionNumber;

//! Project version string for Toast.
FOUNDATION_EXPORT const unsigned char ToastVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Toast/PublicHeader.h>
#import <Toast/UIView+Toast.h>
