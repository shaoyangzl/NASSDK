#import <Flutter/Flutter.h>

@interface ImageCompressPlugin : NSObject<FlutterPlugin>

+(BOOL) showLog;

@end
