#import <Flutter/Flutter.h>

@interface Md5FileChecksumPlugin : NSObject<FlutterPlugin>
@end
