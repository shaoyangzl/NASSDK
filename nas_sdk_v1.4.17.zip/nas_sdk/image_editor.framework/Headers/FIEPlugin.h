//
//  FIEPlugin.h
//  image_editor
//
//  Created by Caijinglong on 2020/5/22.
//

#import <Flutter/Flutter.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FIEPlugin : NSObject <FlutterPlugin>

@end

NS_ASSUME_NONNULL_END
